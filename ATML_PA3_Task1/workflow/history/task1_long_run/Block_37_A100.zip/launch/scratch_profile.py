"""Bounded scratch timing and profiling, followed by fresh official restoration."""
import gc
import time
from pathlib import Path
from baseline_runtime import progress
from evaluation_records import publish

def measure(config, contract):
    import torch
    from transformers import AutoTokenizer
    from official_training import build_method, SourceOrderData, effective_step
    from training_checkpoints import restore_checkpoint
    started=time.monotonic()
    inputs=Path(config['inputs'])
    model,named,optimizer,scaler,reference,peak=build_method(inputs,'lora4','cuda')
    restored=restore_checkpoint(Path(config['root'])/config['resume_checkpoint'],
        config['restore_contract'],model,named,optimizer,scaler,
        progress=lambda phase:progress(config['state'],phase,saving=True))
    data=SourceOrderData(inputs)
    tokenizer=AutoTokenizer.from_pretrained(inputs/'sources/original_model',local_files_only=True)
    records=[]
    # Two scratch updates, discarded. The official model is rebuilt and restored afterward.
    for offset in (1,2):
        update=restored['successful_updates']+offset
        if update>1250:break
        if time.time()+120>=config['soft_wall']:break
        rows=data.batch(update)
        if offset==1:
            record=effective_step(model,named,optimizer,scaler,rows,update,peak,
                tokenizer.pad_token_id,'cuda',{},reference,
                lambda phase:progress(config['state'],'scratch warmup '+phase))
            records.append({'kind':'unprofiled','seconds':record['total_update_seconds_including_retries']})
        else:
            with torch.profiler.profile(activities=[torch.profiler.ProfilerActivity.CPU,
                                                    torch.profiler.ProfilerActivity.CUDA]) as prof:
                effective_step(model,named,optimizer,scaler,rows,update,peak,
                    tokenizer.pad_token_id,'cuda',{},reference,
                    lambda phase:progress(config['state'],'scratch profile '+phase))
            table=prof.key_averages().table(sort_by='self_cuda_time_total',row_limit=30)
            cpu_table=prof.key_averages().table(sort_by='self_cpu_time_total',row_limit=30)
            report=Path(config['root'])/'logs'/(config['run_id']+'_scratch_profile.txt')
            report.write_text(table+'\nCPU totals\n'+cpu_table)
            print(table,flush=True)
    summary={'scratch_updates':len(records)+(1 if 'prof' in locals() else 0),
             'timings':records,'elapsed_seconds':time.monotonic()-started,
             'official_updates_from_pilot':0,'optimization_adopted':False}
    publish(Path(config['root'])/'logs'/(config['run_id']+'_scratch_profile.json'),summary)
    del model,named,optimizer,scaler,reference
    gc.collect();torch.cuda.empty_cache()
    return summary
