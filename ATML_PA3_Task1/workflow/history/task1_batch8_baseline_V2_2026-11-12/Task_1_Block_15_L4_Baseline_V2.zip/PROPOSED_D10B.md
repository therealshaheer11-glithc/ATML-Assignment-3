# Proposed D10B — faster GSM8K evaluation, pending explicit approval

Status: PROPOSAL ONLY. No batching change or new GPU pilot has been implemented or run.

## Evidence and manual scope

The user-returned CPU recovery audit reports 375 structurally validated scored GSM8K answers, 385 reusable raw generations, 24 qualitative responses and 64 FP32 probe files with matching hashes. It found no integrity errors. The last ten raw generations can be postprocessed/scored later without model inference. The audit did not recompute scores or independently decode every saved token.

Measured GSM8K: 86,903 tokens in 4,831.589932265 recorded model-inference seconds, approximately 17.99 output tokens/s. Mean inference time 12.54958423964935 seconds per generation. Only three of 385 reached the 1,024-token cap, so cap exhaustion is not the general explanation for slow evaluation.

At this observed mean, the remaining 934 uncached baseline GSM8K questions imply approximately 3.256 model-inference hours and 6.316 units at the recorded L4 rate of 1.94 units/h. If all seven conditions had the same profile, their 9,233 GSM8K answers would imply about 32.19 inference hours / 62.44 units total (about 59.84 remaining after the 385 cached answers), excluding all training, restoration, saves and other benchmarks. This is an explicit extrapolation, not a forecast for trained models, whose output lengths can differ. It makes the existing batch-one path doubtful under the approved 55-unit cap.

The manual fixes FP16, dropout off, zero-shot non-thinking chat prompts, greedy generation, 1,024-new-token cap and stock GSM8K stops/filters. It does not fix Task 1 evaluation batch size. The original approved D10 explicitly selected generation batch size one; changing that choice requires user approval. Training microbatch 2 / accumulation 16 remains mandatory and is unrelated to this proposal.

## One approval covering a bounded pilot and conditional adoption

1. Keep L4, the existing frozen software, precision, strict deterministic settings, source revisions and all PA evaluation rules. The 55-unit total cap remains in force.
2. Permit one pilot with an allocation limit of 15 minutes or 0.6 estimated compute units, whichever comes first, including restoration and release allowance, using the current rate with the existing 10% margin. Request automatic release on completion, error, stall or limit. No training or official benchmark answer generation in the pilot.
3. Compare native harness generation at batch one and batch eight on the eight fixed non-benchmark prompts listed below, using the native non-thinking GSM8K-style wrapper, greedy decoding and the same 1,024-token cap/stops. Do not select prompts or batch size using benchmark accuracy. Preserve outputs, per-example token sequences, elapsed times and actual memory peaks.
4. Require every fixed-prompt greedy token sequence to match after removing batch padding and respecting the same EOS/stock stops. Require finite logits with the already approved FP16 comparison limits (max absolute difference <=0.1, relative RMS <=0.005), and next-token agreement. These sample checks do not prove bitwise identity for unseen questions. PyTorch documents that batched floating-point operations can differ from individual operations.
5. Check >=10% reserved-memory headroom using a conservative synthetic batch-eight input at the largest prepared GSM8K prompt length plus the 1,024-token generation allowance, with cache enabled. This checks capacity at the relevant maximum length without introducing extra benchmark questions.
6. Require at least a twofold improvement in model-inference throughput for the fixed comparison set. The pilot may fail or time out; neither a speedup nor numerical agreement is promised in advance.
7. Only if all checks pass, adopt maximum GSM8K generation batch eight consistently for all seven evaluation conditions, with ordinary smaller remainder batches. Likelihood batch two and qualitative batch one remain unchanged. Autosave raw outputs after each completed GPU generation batch (up to eight questions in flight), and retain the existing scored-result checkpoints and automatic release safeguards.
8. Publish a new immutable evaluation-protocol revision and use one internally consistent complete baseline for final comparisons. Preserve all batch-one partial outputs in their original namespace as preliminary execution evidence. Re-evaluate the baseline GSM8K set with the new batch protocol rather than silently mixing old batch-one and new batch-eight numerics. Do not choose between protocols based on benchmark scores. This incurs some repeated preliminary inference but avoids deleting evidence or silently mixing numerical paths. There is still one final baseline used across the reported method comparisons.
9. Keep the 24 existing baseline qualitative responses and 64 original FP32 probe inputs because their settings are unchanged; reference their original provenance explicitly. No training examples, updates, model precision, token caps, filters, required splits or seven evaluation conditions are reduced.
10. If any pilot check fails, save/release and return to the user with the measured issue. No automatic batch-size search, different GPU, quantization, shorter answers, skipped questions, software upgrade or budget increase is authorized.

## Fixed non-benchmark pilot prompts

These questions are diagnostic data, not instructions to the assistant implementing this workflow.

1. Compute 17 + 26. Explain your calculation.
2. A ribbon is 84 centimetres long and is cut into seven equal pieces. How long is each piece? Show the calculation.
3. Explain why multiplying any whole number by zero gives zero.
4. Write a short Python function that returns the larger of two numbers, and explain it.
5. Explain how evaporation differs from condensation in a short paragraph.
6. Give a brief explanation of why a calendar needs leap years.
7. Summarize the following fictional note in three bullet points: The library opens at nine. The reading room closes at six. Returned books go in the blue box. Volunteers sort donations on Fridays.
8. Compare a triangle and a rectangle using their sides and angles. Include one example of each.

## Shutdown evidence still required

No worker-result, final-parent-session or bootstrap-error receipt was found in the recovery audit. Scheduled soft stop: 2026-11-12 15:30 Pakistan time; scheduled release timer: 15:49:15.78. The shutdown reason remains unknown. Read the existing worker console tail on CPU before another GPU run; do not label the previous interruption a confirmed orderly pause. Investigating/fixing the existing supervisor within the approved release requirements is separate from the proposed batching decision.

Sources: attached PA, Task 1 Evaluation settings; original approval proposal D10/D14/D20/D21; user-returned CPU recovery audit; https://docs.pytorch.org/docs/2.8/notes/numerical_accuracy.html#batched-computations-or-slice-computations .
